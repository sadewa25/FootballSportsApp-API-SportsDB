package trunojoyo.sadewa.adminsi.footballsportsapps

import android.support.test.espresso.Espresso
import android.support.test.espresso.Espresso.onView
import android.support.test.espresso.action.ViewActions
import android.support.test.espresso.action.ViewActions.click
import android.support.test.espresso.action.ViewActions.pressBack
import android.support.test.espresso.assertion.ViewAssertions
import android.support.test.espresso.assertion.ViewAssertions.matches
import android.support.test.espresso.contrib.RecyclerViewActions
import android.support.test.espresso.matcher.ViewMatchers
import android.support.test.espresso.matcher.ViewMatchers.*
import android.support.test.rule.ActivityTestRule
import android.support.test.runner.AndroidJUnit4
import android.support.v7.widget.RecyclerView
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import trunojoyo.sadewa.adminsi.footballsportsapps.R.id.*

@RunWith(AndroidJUnit4::class)
class MainActivityTest{

    @Rule
    @JvmField var activityRule = ActivityTestRule(MainActivity::class.java)

    @Test
    fun testBehaviourMatchesNext(){
        onView(ViewMatchers.withId(navigation))
            .check(ViewAssertions.matches(ViewMatchers.isDisplayed()))

        onView(withId(tabs_main)).perform(click())
        onView(withText("NEXT")).perform(click())

        Thread.sleep(3000)
        Espresso.onView(ViewMatchers.withId(recycler_next_match))
            .check(ViewAssertions.matches(ViewMatchers.isDisplayed()))
        Espresso.onView(ViewMatchers.withId(recycler_next_match)).perform(RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(12))
        Thread.sleep(5000)
        Espresso.onView(ViewMatchers.withId(recycler_next_match)).perform(
            RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(0, ViewActions.click()))
        pressBack()
    }

    @Test
    fun testBehaviourMatchesLast(){
        onView(ViewMatchers.withId(navigation))
            .check(ViewAssertions.matches(ViewMatchers.isDisplayed()))

        onView(withId(tabs_main)).perform(click())
        onView(withText("LAST")).perform(click())

        Thread.sleep(3000)
        Espresso.onView(ViewMatchers.withId(recycler_last_match))
            .check(ViewAssertions.matches(ViewMatchers.isDisplayed()))
        Espresso.onView(ViewMatchers.withId(recycler_last_match)).perform(RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(12))
        Thread.sleep(5000)
        Espresso.onView(ViewMatchers.withId(recycler_last_match)).perform(
            RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(0, ViewActions.click()))
        pressBack()
    }

}